/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Criptare;
import java.util.Scanner;
/**
 *
 * @author Viorel Elefterescu
 */
public class Criptare {
    public static void criptare() {
        Scanner scan = new Scanner(System.in);
		
	int x, y; // stilul de aplicare  al criptarii (+x si -y)        
       	String parola; // sirul parola	       	
                
	System.out.println("*** CRIPTARE ***\n");	      	
    
        System.out.println("***Introduceti parola:");	
	parola = scan.nextLine();        
        //System.out.println("Parola are: " + parola.length() + " caractere\n" + parola + "\n");
        int pass_crypt[] = new int[parola.length()]; // parola criptata
        
        // afisarea codului ascii al parolei	
        //System.out.println("***Codul ascii al parolei este: ");
	for (int i = 0; i < parola.length(); i++) {		
                //System.out.print((int)parola.charAt(i) + " ");
	}
	System.out.println();

	//introducem cate elem are cheia de la tastatura	
        System.out.println("***Cate elemente are cheia?");	
        int k = scan.nextInt();  // cate elemente are cheia
        int key[] = new int[k]; // cheia
		
	//introducem elementele cheii de la tastatura	
        System.out.println("***Introduceti cheia: ");
	for (int i = 0; i < k; i++) {		
                key[i] = scan.nextInt();
	}        
	System.out.println();
	
	// introducerea si afisarea stilului de aplicare a cheii		
        System.out.println("***Introduceti stilul de criptare: ");	
        x = scan.nextInt();
        y = scan.nextInt();	
        //System.out.println("***Stilul in care se aplica cheia este: +" + x + " si -" + y + "\n");
        System.out.println();
        
	// criptarea parolei in codul ascii	
        System.out.println("***Sirul criptat este: ");
	int contorZ = 0; // contor pentru lungimea parolei si a parolei criptate
	int contor2 = 0; // contor pentru cheie
	while (contorZ < parola.length()) {
		for (int i = 0; i < x; i++) {
			if (contorZ == parola.length()) {
				break;
			}
			if (contor2 == k) {
				contor2 = 0;
			}
			pass_crypt[contorZ] = key[contor2] + parola.charAt(contorZ);
			contorZ++;
			contor2++;
		}
		for (int i = 0; i < y; i++) {
			if (contorZ == parola.length()) {
				break;
			}
			if (contor2 == k) {
				contor2 = 0;
			}
			pass_crypt[contorZ] = key[contor2] - parola.charAt(contorZ);
			contorZ++;
			contor2++;
		}		
	}
	// afisarea parolei criptate
	for (int i = 0; i < parola.length(); i++) {		
                System.out.print(pass_crypt[i] + " ");
	}	
        System.out.println("\n");
    }
}
// 1312 2159 3173 4175 1234 2159 3038 1124 1957 3155 1215 2152 3157 4179 1365 2173 3020 1059  >>exemplu sir criptat (stil aplicare cheie 1 - 6)
// 1247 2267 3274 4278 1266 2274 3135 1092 2054 3264  >> exemplu cheie 10 elemente
// 1161 2162 3163 4164 1165 2166 3167   >>exemplu cheie 7 elemente

