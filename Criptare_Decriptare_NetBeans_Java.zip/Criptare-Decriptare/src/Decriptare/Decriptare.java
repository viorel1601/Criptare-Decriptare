/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Decriptare;
import java.util.Scanner;
/**
 *
 * @author Viorel Elefterescu
 */
public class Decriptare {
    public static void decriptare(){
        Scanner scan = new Scanner(System.in);
                		
	int x, y; // stilul criptarii si decriptarii
	
        System.out.println("*** DECRIPTARE ***");
        System.out.println();
        
	//introducem datele criptate	
        System.out.println("***Introduceti datele criptate: ");
	String pass_crypt;
        pass_crypt = scan.nextLine();   
        
        int parola[] = new int[pass_crypt.length()];
        int contorParola = 0, nr = 0;
        for(int i = 0; i < pass_crypt.length(); i++){         
            if(pass_crypt.charAt(i) != ' '){
                nr = nr * 10 + (pass_crypt.charAt(i) - '0') % 10;
                parola[contorParola] = nr;                
            }else{
                contorParola++;
                nr = 0;
            }
        }
        contorParola++;
	System.out.println();
        
	//introducem de la tastatura cate elemente are cheia        	
        System.out.println("***Cate elemente are cheia?");
	int k = scan.nextInt(); //cate elemente are cheia
        int key[] = new int[k];
	//System.out.println();
	
	//introducem cheia de la tastatura	
        System.out.println("***Introduceti cheia: ");
	for (int i = 0; i < k; i++) {
		key[i] = scan.nextInt();
	}
	System.out.println();

	// introducerea si afisarea stilului de aplicare a cheii	
        System.out.println("***Introduceti stilul de criptare: ");	
        x = scan.nextInt();
        y = scan.nextInt();	
        //System.out.println("***Stilul in care se aplica cheia este: +" + x + " si -" + y + "\n");

	// decriptarea parolei in codul ascii	
        System.out.println("***Sirul decriptat partial este: \n");
	int contorZ = 0; // contor pentru lungimea parolei si a parolei criptate
	int contor2 = 0; // contor pentru cheie
	while (contorZ < contorParola) {
		for (int i = 0; i < x; i++) {
			if (contorZ == contorParola) {
				break;
			}			
			if (contor2 == k) {
				contor2 = 0;
			}
			parola[contorZ] -= key[contor2];
			contorZ++;
			contor2++;
		}
		for (int i = 0; i < y; i++) {
			if (contorZ == contorParola) {
				break;
			}			
			if (contor2 == k) {
				contor2 = 0;
			}
			parola[contorZ] = key[contor2] - parola[contorZ];
			contorZ++;
			contor2++;
		}
	}

	// afisarea parolei decriptate in codul ascii
	for (int i = 0; i < contorParola; i++) {		
                //System.out.print((int)parola[i] + " ");
	}
	//System.out.println();

	// afisarea din codul ascii in parola		
        System.out.println("***Decriptare >> Parola este: ");        
	for (int i = 0; i < contorParola; i++) {		
                System.out.print((char)parola[i]);                
	}
	System.out.println();
    }
}
// 1312 2159 3173 4175 1234 2159 3038 1124 1957 3155 1215 2152 3157 4179 1365 2173 3020 1059  >>exemplu sir criptat (stil aplicare cheie 1 - 6)
// 1247 2267 3274 4278 1266 2274 3135 1092 2054 3264  >> exemplu cheie 10 elemente
// 1161 2162 3163 4164 1165 2166 3167   >>exemplu cheie 7 elemente