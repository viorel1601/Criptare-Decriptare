/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import Criptare.Criptare;
import Decriptare.Decriptare;
import java.util.Scanner;
/**
 *
 * @author Viorel Elefterescu
 */
public class Main {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        System.out.println("*** Program Criptare / Decriptare ***");	
        System.out.println("Introduceti C de la criptare sau D de la decriptare pentru a incepe:");
	char start = scan.next().charAt(0);	
        switch (start) {        
            case 'c':
                Criptare.criptare();
                break;
            case 'C':
                Criptare.criptare();
                break;        
            case 'd':
                Decriptare.decriptare();
                break;
            case 'D':
                Decriptare.decriptare();
                break;
            default:                
                System.out.println("Nu exista eceasta optiune. Incearca din nou.");
                break;
        }        
    }    
}
