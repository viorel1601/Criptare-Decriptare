#include "stdafx.h"

#include <iostream>
#include <string>
using namespace std;

void criptare() {
	char parola[1000]; // sirul parola
	int i, key[15];  // cheia
	int pass_crypt[1000]; // parola criptata
	int k;  // cate elemente are cheia		
	int elementeParola; // contor pentru nr de elemente al parolei
	int x, y; // stilul de aplicare  al criptarii (+x si -y)

	cout << "*** CRIPTARE ***" << "\n";

	//scriem sirul parola de la tastatura		
	cout << "Cate elemente are parola?" << "\n";
	cin >> elementeParola;
	cout << "\n***Introduceti parola:" << "\n";
	parola[elementeParola] = '\0';
	for (i = 0; i < elementeParola; i++) {
		cin >> parola[i];
	}	
	cout << "Parola are: " << elementeParola << "caractere" << "\n";

	//introducem cate elem are cheia de la tastatura
	cout << "***Cate elemente are cheia?" << "\n";
	cin >> k;
	cout << "\n";
	
	//introducem elementele cheii de la tastatura
	cout << "***Introduceti cheia: " << "\n";
	for (i = 0; i < k; i++) {
		cin >> key[i];
	}
	cout << "\n";

	// afisarea codului ascii al parolei
	cout << "\n";
	cout << "***Codul ascii al parolei este: " << "\n";
	for (i = 0; i < elementeParola; i++) {
		cout << (int)parola[i] << " ";
	}
	cout << "\n";

	// introducerea si afisarea stilului de aplicare a cheii
	cout << "***Introduceti stilul de criptare: " << "\n";	
	cin >> x >> y;
	cout << "***Stilul in care se aplica cheia este: +" << x << " si -" << y << "\n";

	// criptarea parolei in codul ascii
	cout << "***Sirul criptat este: ";
	int contorZ = 0; // contor pentru lungimea parolei si a parolei criptate
	int contor2 = 0; // contor pentru cheie
	while (contorZ < elementeParola) {
		for (i = 0; i < x; i++) {
			if (contorZ == elementeParola) {
				break;
			}
			if (contor2 == k) {
				contor2 = 0;
			}
			pass_crypt[contorZ] = key[contor2] + parola[contorZ];
			contorZ++;
			contor2++;
		}
		for (i = 0; i < y; i++) {
			if (contorZ == elementeParola) {
				break;
			}
			if (contor2 == k) {
				contor2 = 0;
			}
			pass_crypt[contorZ] = key[contor2] - parola[contorZ];
			contorZ++;
			contor2++;
		}
		cout << "\n";
	}
	// afisarea parolei criptate
	for (i = 0; i < elementeParola; i++) {
		cout << pass_crypt[i] << " ";
	}
	cout << "\n";
}
// exemple cheie
// 1247 2267 3274 4050 1064 2058 3135 1230 2270 3264 4062 1049 2065 3053 1262 2277 3262 4047   (cu stil 3 4)
// 1247 2267 3274 4278 1266 2274 3135 1092 2054 3264 4266 1281 2267 3281 1262 2047 3064 4047   (cu stil 6 3)
// 1161 2162 3163 4164 1165 2166 3167   cheia


void decriptare() {
	char parola[1000];
	int i, key[15];
	int pass_crypt[1000];
	int n; //cate elemente sunt criptate
	int k; // cate elemente are cheia
	int x, y; // stilul criptarii si decriptarii

	cout << "*** DECRIPTARE ***" << "\n";

	//introducem cate elemente sunt criptate
	cout << "Cate elemente sunt criptate?" << "\n";
	cin >> n;
	cout << "\n";

	//introducem datele criptate
	cout << "***Introduceti datele criptate: " << "\n";
	for (i = 0; i < n; i++) {
		cin >> pass_crypt[i];
	}
	cout << "\n";

	//introducem de la tastatura cate elemente are cheia        
	cout << "***Cate elemente are cheia?" << "\n";
	cin >> k;
	cout << "\n";
	
	//introducem cheia de la tastatura
	cout << "***Introduceti cheia: " << "\n";
	for (i = 0; i < k; i++) {
		cin >> key[i];
	}
	cout << "\n";

	// introducerea si afisarea stilului de aplicare a cheii
	cout << "***Introduceti stilul de criptare: " << "\n";
	cin >> x >> y;
	cout << "***Stilul in care se aplica cheia este: +" << x << " si -" << y << "\n";

	// decriptarea parolei in codul ascii
	cout << "***Sirul decriptat partial este: " << "\n";
	int contorZ = 0; // contor pentru lungimea parolei si a parolei criptate
	int contor2 = 0; // contor pentru cheie
	while (contorZ < n) {
		for (i = 0; i < x; i++) {
			if (contorZ == n) {
				break;
			}			
			if (contor2 == k) {
				contor2 = 0;
			}
			parola[contorZ] = pass_crypt[contorZ] - key[contor2];
			contorZ++;
			contor2++;
		}
		for (i = 0; i < y; i++) {
			if (contorZ == n) {
				break;
			}			
			if (contor2 == k) {
				contor2 = 0;
			}
			parola[contorZ] = key[contor2] - pass_crypt[contorZ];
			contorZ++;
			contor2++;
		}
	}

	// afisarea parolei decriptate in codul ascii
	for (i = 0; i < n; i++) {
		cout << (int)parola[i] << " ";
	}
	cout << "\n";

	// afisarea din codul ascii in parola
	cout << "***Decriptare >> Parola este: " << "\n";	
	for (i = 0; i < n; i++) {
		cout << parola[i];
	}
	cout << "\n";
}
// exemple cheie
// 1247 2267 3274 4050 1064 2058 3135 1230 2270 3264 4062 1049 2065 3053 1262 2277 3262 4047   (cu stil 3 4)
// 1247 2267 3274 4278 1266 2274 3135 1092 2054 3264 4266 1281 2267 3281 1262 2047 3064 4047   (cu stil 6 3)
// 1161 2162 3163 4164 1165 2166 3167   cheia

int main() {		
	cout << "*** Program Criptare / Decriptare ***" << "\n";
	cout << "Introduceti C de la criptare sau D de la decriptare pentru a incepe:" << "\n";
	char start;
	cin >> start;
	if (start == 'c' || start == 'C') {
		criptare();
	}else if (start == 'd' || start == 'D') {
		decriptare();
	}else {
		cout << "Nu exista eceasta optiune. Incearca din nou.";
	}
	return 0;
}